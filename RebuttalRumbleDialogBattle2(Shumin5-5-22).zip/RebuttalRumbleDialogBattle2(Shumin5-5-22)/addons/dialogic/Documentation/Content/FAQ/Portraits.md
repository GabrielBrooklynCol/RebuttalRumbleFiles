# Portraits not showing in game?

Before the characters show up on screen, you need to make them join your current scene using the [Character Join](../Events/001.md). 

If you used the join event and you still don't see them, you should try modifying the offset and scale values in your character's portrait.