# Getting started 

The video is a bit outdated since it was made using the previous version, but the concepts are the same. You can watch the video [here](https://www.youtube.com/watch?v=sYjgDIgD7AY) or use the new and improved guide [here](./BeginnersGuideStepByStep)